<?php
class Divido_Pay_Block_Price extends Mage_Core_Block_Template
{
    public function getPrice ()
    {
        $price = 89898;

        return $price;
    }
}
