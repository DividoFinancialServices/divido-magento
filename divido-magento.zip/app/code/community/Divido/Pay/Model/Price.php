<?php
class Divido_Pay_Model_Price extends Mage_Core_Model_Abstract
{
    public function getStatus ()
    {
        return 'it\'s on';
    }
}
