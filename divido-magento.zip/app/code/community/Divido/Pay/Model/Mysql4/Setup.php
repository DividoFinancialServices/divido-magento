<?php
//die('here');
class Divido_Pay_Model_Mysql4_Setup extends Mage_Catalog_Model_Resource_Eav_Mysql4_Setup {
}
