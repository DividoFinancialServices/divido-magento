<?php

class Divido_ApiError extends Divido_Error
{
}
